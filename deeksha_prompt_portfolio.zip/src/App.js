
import React from "react";
import "./App.css";

const prompts = [
  {
    title: "Blog Post Generator for Startups",
    need: "Client needed SEO-friendly blog content",
    prompt:
      "Act like an expert content marketer. Write a 1000-word blog post on '5 AI Tools Every Startup Should Use' including catchy headings, bullet points, and a strong CTA.",
    result:
      "Structured blog with headings, bullet points, keywords, and a CTA. Reduced content time by 4 hours.",
  },
  {
    title: "Midjourney Prompt - AI Girl in Cyber World",
    need: "Client wanted visually rich AI-generated art",
    prompt:
      "A futuristic Indian woman in a cyberpunk city at night, glowing AI implants, vivid neon lights, ultra-detailed, 3D render, digital art style",
    result:
      "Generated stunning, detailed artwork with neon effects and futuristic design.",
  },
  {
    title: "Instagram Caption Generator",
    need: "Travel page needed fun and engaging captions",
    prompt:
      "Act like a witty travel influencer. Write a short, fun caption for a beach sunset in Bali. Include 3 hashtags.",
    result:
      "Created a catchy caption with relevant hashtags and informal tone.",
  },
  {
    title: "Resume Summary Generator",
    need: "IT student needed a strong resume summary",
    prompt:
      "You are a resume coach. Write a 3-line profile summary for a B.Tech IT graduate with Python internship and interest in AI.",
    result:
      "Generated a professional, concise summary highlighting skills and interests.",
  },
  {
    title: "Daily Standup Summary Generator",
    need: "Team needed auto-summarized updates",
    prompt:
      "Summarize these tasks into a daily standup, grouping by person and status (completed/pending).",
    result:
      "Output clearly grouped tasks by status and contributor for daily reporting.",
  },
];

function App() {
  return (
    <div className="container">
      <header className="header">
        <h1>Deeksha Prajapati</h1>
        <h2>Prompt Engineer | B.Tech IT Graduate | AI Enthusiast</h2>
        <p>
          I'm a B.Tech (Information Technology) graduate passionate about artificial
          intelligence, automation, and prompt engineering. I help individuals and startups
          optimize their work with custom ChatGPT and Midjourney prompts that save time and
          generate better results.
        </p>
      </header>

      <div className="prompt-grid">
        {prompts.map((item, index) => (
          <div className="card" key={index}>
            <h3>{item.title}</h3>
            <strong>Client Need:</strong>
            <p>{item.need}</p>
            <strong>Prompt Used:</strong>
            <pre>{item.prompt}</pre>
            <strong>Result:</strong>
            <p>{item.result}</p>
          </div>
        ))}
      </div>

      <footer className="footer">
        <p>Want to collaborate or hire me for a project?</p>
        <a href="mailto:deeksha@example.com" className="contact-button">
          Contact Me
        </a>
        <p className="social-links">
          Email: deeksha@example.com | LinkedIn: linkedin.com/in/deeksha-prajapati
        </p>
      </footer>
    </div>
  );
}

export default App;
